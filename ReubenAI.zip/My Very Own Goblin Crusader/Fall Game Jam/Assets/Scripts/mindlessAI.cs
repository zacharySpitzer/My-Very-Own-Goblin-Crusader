﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Not turn based?

public class mindlessAI : MonoBehaviour
{
    Transform transf;
    public LayerMask wall;

    public bool chase;
    public float chaseDistance;

    Random rnd = new Random();
    int count = 0;
    public int moveWait;

    int acount;
    int bcount;
    int ccount;
    int dcount;
    int ecount;

    // Use this for initialization
    void Start()
    {
        transf = gameObject.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {
        int ran = Random.Range(0, 4);
        count++;


        if (count == moveWait)
        {

            if (!isClose(chaseDistance) || (isClose(chaseDistance) && !chase))
            {
                count = 0;
                if (!isUpBlocked() && ran == 0)
                {
                    transf.Translate(0, 1f, 0);
                    //acount++;
                    //Debug.Log(ran + " : " + acount);
                }
                if (!isLeftBlocked() && ran == 2)
                {
                    transf.Translate(-1f, 0, 0);
                    //bcount++;
                    //Debug.Log(ran + " : " + bcount);
                }
                if (!isDownBlocked() && ran == 1)
                {
                    transf.Translate(0, -1f, 0);
                    //ccount++;
                    //Debug.Log(ran + " : " + ccount);

                }
                if (!isRightBlocked() && ran == 3)
                {
                    transf.Translate(1f, 0, 0);
                    //dcount++;
                    //Debug.Log(ran + " : " + dcount);
                }
                else if (ran == 2)
                {
                    transf.Translate(0, 0, 0);
                    //ecount++;
                    //Debug.Log(ran + " : " + ecount);
                }
            }
            else if (chase) 
            {
                count = 0;
                transf.Translate(getMove());
            }
        }

        
        //Debug.Log(getDirection());
        //Debug.Log(getMove());
        //Debug.Log("Close? " + isClose(chaseDistance));
    }






    bool isDownBlocked()
    {

        

        Vector2 position = transform.position;
        Vector2 downdir = (Vector2.down) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, downdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, downdir, distance, wall);

        if (hit.collider != null)
        {
            return true;
        }

        return false;
    }

    bool isUpBlocked()
    {
        Vector2 position = transform.position;
        Vector2 updir = (Vector2.up) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, updir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, updir, distance, wall);

        if (hit.collider != null)
        {
            return true;
        }

        return false;
    }

    bool isLeftBlocked()
    {
        Vector2 position = transform.position;
        Vector2 leftdir = (Vector2.left) * 1.5f;
        float distance = 1f;

        Debug.DrawRay(position, leftdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, leftdir, distance, wall);

        if (hit.collider != null)
        {
            return true;
        }

        return false;
    }

    bool isRightBlocked()
    {
        Vector2 position = transform.position;
        Vector2 rightdir = (Vector2.right) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, rightdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, rightdir, distance, wall);

        if (hit.collider != null)
        {
            return true;
        }

        return false;
    }










    Vector3 getDirection()
    {
        return gameObject.transform.position - movement.instance.playerLoc();
    }
    bool isClose(float chaseDistance)
    {
        if((getDirection().x < chaseDistance && getDirection().x > -chaseDistance) 
            && (getDirection().y < chaseDistance && getDirection().y > -chaseDistance))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    Vector3 getMove()
    {
        Vector3 mov = Vector3.zero;

        if (getDirection().y < 0)
        {
            mov.y = 1;
        }
        if (getDirection().y == 0)
        {
            mov.y = 0;
        }
        if (getDirection().y > 0)
        {
            mov.y = -1;
        }

        if (getDirection().x < 0)
        {
            mov.x = 1;
        }
        if (getDirection().x == 0)
        {
            mov.x = 0;
        }
        if (getDirection().x > 0)
        {
            mov.x = -1;
        }

        return mov;

    }









    
}