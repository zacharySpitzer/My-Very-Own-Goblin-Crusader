﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Not turn based?

public class movement : MonoBehaviour
{
    public GameObject front;
    public GameObject back;


    public static movement instance;


    Transform transf;
    public LayerMask wall;

    public GameObject axRot;

    // Use this for initialization
    void Start()
    {
        instance = this;

        transf = gameObject.GetComponent<Transform>();
    }

    // Update is called once per frame
    void Update()
    {


        if (!isUpBlocked() && Input.GetKeyDown(KeyCode.W))
        {
            transf.Translate(0, 1f, 0);
            front.SetActive(false);
            back.SetActive(true);
        }

        if (!isLeftBlocked() && Input.GetKeyDown(KeyCode.A))
        {
            transf.Translate(-1f, 0, 0);
            front.SetActive(true);
            back.SetActive(false);
        }

        if (!isDownBlocked() && Input.GetKeyDown(KeyCode.S))
        {
            transf.Translate(0, -1f, 0);
            front.SetActive(true);
            back.SetActive(false);

        }

        if (!isRightBlocked() && Input.GetKeyDown(KeyCode.D))
        {
            transf.Translate(1f, 0, 0);
            front.SetActive(true);
            back.SetActive(false);
        }

        // THIS IS WHAT WE SHOULD DO FOR MOVEMENT WITH GETAXIS

        //transf.Transltate(Input.GetAxis("Horizontal"), Input.GetAxis("Horizontal"), 0);

        // Than set inputs to snapto, so they are always 1, 0, or -1. This will also
        // add horizontal movement in our final build.

        // all movement in one line.



        if(Input.GetKey(KeyCode.Y))
        {
            axRot.SetActive(true);
            axRot.transform.Rotate(0, 0, -3);
        }
        else
        {
            axRot.SetActive(false);
            axRot.transform.rotation = Quaternion.Euler(0,0,15);
        }

    }


















    













    bool isDownBlocked()
    {
        Vector2 position = transform.position;
        Vector2 downdir = (Vector2.down) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, downdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, downdir, distance, wall);

        if (hit.collider != null)
        {
            Debug.Log("1");
            return true;
        }

        return false;
    }

    bool isUpBlocked()
    {
        Vector2 position = transform.position;
        Vector2 updir = (Vector2.up) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, updir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, updir, distance, wall);

        if (hit.collider != null)
        {
            Debug.Log("2");
            return true;
        }

        return false;
    }

    bool isLeftBlocked()
    {
        Vector2 position = transform.position;
        Vector2 leftdir = (Vector2.left) * 1.5f;
        float distance = 1f;

        Debug.DrawRay(position, leftdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, leftdir, distance, wall);

        if (hit.collider != null)
        {
            Debug.Log("3");
            return true;
        }

        return false;
    }

    bool isRightBlocked()
    {
        Vector2 position = transform.position;
        Vector2 rightdir = (Vector2.right) * 1f;
        float distance = 1f;

        Debug.DrawRay(position, rightdir, Color.red);
        RaycastHit2D hit = Physics2D.Raycast(position, rightdir, distance, wall);

        if (hit.collider != null)
        {
            Debug.Log("4");
            return true;
        }

        return false;
    }








    public Vector3 playerLoc()
    {
        return transf.position;
    }

}