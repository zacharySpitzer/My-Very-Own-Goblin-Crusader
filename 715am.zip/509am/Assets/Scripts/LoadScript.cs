﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class LoadScript : MonoBehaviour
{
    public static LoadScript instance;

    public GameObject menuPanel;
    public GameObject uiPanel;
    
    public Text wealthDisplay;
    string wealthS = "Wealth : ";

    public Text timer;
    string timeS = "Time : ";
    int wealth;

    public Image oneper;
    public Image twoper;
    public Image threeper;
    public Image fourper;
    public Image fiveper;
    public Image sixper;
    public Image sevenper;
    public Image eightper;
    public Image nineper;
    public Image tenper;
    int health;

    bool loaded = false;
    private void Start()
    {
        instance = this;

        menuPanel.SetActive(true);
        uiPanel.SetActive(false);
        DontDestroyOnLoad(gameObject);

    }
    private void Update()
    {
        if(Input.anyKeyDown && !loaded)
        {
            LoadForest();
            loaded = true;
        }


        //TIMER OUT
        float time = Time.timeSinceLevelLoad;
        timer.text = timeS + time.ToString("n2");
        //WEALTH OUT
        wealthDisplay.text = wealthS + wealth;
        //HEALTH OUT
        if(health <= 0)
        {
            oneper.gameObject.SetActive(false);
            twoper.gameObject.SetActive(false);
            threeper.gameObject.SetActive(false);
            fourper.gameObject.SetActive(false);
            fiveper.gameObject.SetActive(false);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if(health > 0 && health <= 5)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(false);
            threeper.gameObject.SetActive(false);
            fourper.gameObject.SetActive(false);
            fiveper.gameObject.SetActive(false);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 5 && health <= 10)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(false);
            fourper.gameObject.SetActive(false);
            fiveper.gameObject.SetActive(false);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 10 && health <= 15)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(false);
            fiveper.gameObject.SetActive(false);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 15 && health <= 20)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(false);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 20 && health <= 25)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(false);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 25 && health <= 30)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(true);
            sevenper.gameObject.SetActive(false);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 30 && health <= 35)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(true);
            sevenper.gameObject.SetActive(true);
            eightper.gameObject.SetActive(false);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 35 && health <= 40)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(true);
            sevenper.gameObject.SetActive(true);
            eightper.gameObject.SetActive(true);
            nineper.gameObject.SetActive(false);
            tenper.gameObject.SetActive(false);
        }
        if (health > 40 && health <= 45)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(true);
            sevenper.gameObject.SetActive(true);
            eightper.gameObject.SetActive(true);
            nineper.gameObject.SetActive(true);
            tenper.gameObject.SetActive(false);
        }
        if (health > 45 && health <= 50)
        {
            oneper.gameObject.SetActive(true);
            twoper.gameObject.SetActive(true);
            threeper.gameObject.SetActive(true);
            fourper.gameObject.SetActive(true);
            fiveper.gameObject.SetActive(true);
            sixper.gameObject.SetActive(true);
            sevenper.gameObject.SetActive(true);
            eightper.gameObject.SetActive(true);
            nineper.gameObject.SetActive(true);
            tenper.gameObject.SetActive(true);
        }
    }


    public void LoadTown()
    {
        SceneManager.LoadScene("FarmTown");
    }

    public void LoadForest()
    {
        menuPanel.SetActive(false);
        uiPanel.SetActive(true);
        SceneManager.LoadScene("Forest");


    }

    public void ExitApplication()
    {
        Application.Quit();
    }


    public void Wealth(int gold)
    {
        wealth = gold;
        return;
    }

    public void Health(int hp)
    {
        health = hp;
        return;
    }

}


