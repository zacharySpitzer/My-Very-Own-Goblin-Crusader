﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class chest : MonoBehaviour {

    public static chest instance;

    public GameObject open;
    public GameObject close;
    GameObject coin;
    public GameObject copperCoin;
    public GameObject silverCoin;
    public GameObject goldCoin;
    public GameObject platinumCoin;

    public bool copperAdd;
    public bool silverAdd;
    public bool goldAdd;
    public bool platinumAdd;

    // Use this for initialization
    void Start () {

        if (copperAdd)
        {
            coin = copperCoin;
        }
        if (silverAdd)
        {
            coin = silverCoin;
        }
        if (goldAdd)
        {
            coin = goldCoin;
        }
        if (platinumAdd)
        {
            coin = platinumCoin;
        }

        instance = this;
        close.SetActive(true);
        open.SetActive(false);
        coin.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {
		
	}


    public void Open()
    {
        close.SetActive(false);
        open.SetActive(true);
        coin.SetActive(true);
        Destroy(coin, 1);

        if (copperAdd)
        {
            WORKINGMOVEMENT.instance.copperAdd();
        }
        if (silverAdd)
        {
            WORKINGMOVEMENT.instance.silverAdd();
        }
        if (goldAdd)
        {
            WORKINGMOVEMENT.instance.goldAdd();
        }
        if (platinumAdd)
        {
            WORKINGMOVEMENT.instance.platinumAdd();
        }

        Debug.Log("Open");
    }
}
