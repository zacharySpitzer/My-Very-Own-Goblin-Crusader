﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadScript : MonoBehaviour
{
    public GameObject menuPanel;
    public GameObject uiPanel;

    private void Start()
    {
        menuPanel.SetActive(true);
        uiPanel.SetActive(false);
        DontDestroyOnLoad(gameObject);
    }
    public void LoadForest()
    {
        menuPanel.SetActive(false);
        uiPanel.SetActive(true);
        SceneManager.LoadScene("Forest");
    }

    public void ExitApplication()
    {
        Application.Quit();
    }
}


