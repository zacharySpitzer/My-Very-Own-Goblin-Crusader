﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Damageable : MonoBehaviour
{
    public int maxHP;       // This has to be set in the inspector
    public int currentHP;
    public bool hasAttacked;

    void Start()
    {
        currentHP = maxHP;
    }

    public void doDamage(int damage)
    {
        currentHP -= damage;
        hasAttacked = true;
        StartCoroutine(damageWait());

        if (currentHP <= 0)
        {
            Destroy(gameObject);
        }
    }

    IEnumerator damageWait()
    {
        yield return new WaitForSeconds(2);
        hasAttacked = false;
    }
}
