﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenu : MonoBehaviour
{
    public GameObject canvas;
    public GameObject menuPanel;
    public GameObject exitPanel;

    public static MainMenu instance;

    string menuThing = "Menu";
    string Level1 = "Forest";
    string Level2 = "FarmTown";
    string Level3 = "Dungeon";
    string Level4 = "ThroneRoom";

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            SceneManager.sceneLoaded += OnSceneLoaded;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        DontDestroyOnLoad(gameObject);
        menuPanel.SetActive(true);
        exitPanel.SetActive(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            ForestButton();
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            FarmButton();
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            DungeonButton();
        }

        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            ThroneButton();
        }

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            EndGame();
        }

        if (Input.GetKeyDown(KeyCode.Q) && Input.GetKey(KeyCode.LeftShift))
        {
            Debug.Log("Test");
            Quit();
        }
    }

    public void ForestButton()
    {
        menuPanel.SetActive(false);
        exitPanel.SetActive(true);
        SceneManager.LoadScene(Level1);
    }

    public void FarmButton()
    {
        menuPanel.SetActive(false);
        exitPanel.SetActive(true);
        SceneManager.LoadScene(Level2);
    }

    public void DungeonButton()
    {
        menuPanel.SetActive(false);
        exitPanel.SetActive(true);
        SceneManager.LoadScene(Level3);
    }

    public void ThroneButton()
    {
        menuPanel.SetActive(false);
        exitPanel.SetActive(true);
        SceneManager.LoadScene(Level4);
    }

    public void EndGame()
    {
        exitPanel.SetActive(false);
        SceneManager.LoadScene(menuThing);
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode sceneMode)
    {
        if (menuThing == scene.name)
        {
            Debug.Log("Main Menu");
            menuPanel.SetActive(true);
            exitPanel.SetActive(false);
        }

        Debug.Log("Scene Loaded: " + scene.name);
        Debug.Log(sceneMode);
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#endif

        Application.Quit();
    }
}
